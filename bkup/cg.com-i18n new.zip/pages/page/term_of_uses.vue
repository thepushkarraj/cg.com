<template>
  <spa />
</template>

<script>
export default {
  layout: 'web'
}
</script>
