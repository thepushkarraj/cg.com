import Vue from 'vue'
import Vuex from 'vuex'
import Meta from 'vue-meta'
import ClientOnly from 'vue-client-only'
import NoSsr from 'vue-no-ssr'
import { createRouter } from './router.js'
import NuxtChild from './components/nuxt-child.js'
import NuxtError from '..\\layouts\\error.vue'
import Nuxt from './components/nuxt.js'
import App from './App.js'
import { setContext, getLocation, getRouteData, normalizeError } from './utils'
import { createStore } from './store.js'

/* Plugins */

import nuxt_plugin_plugin_ddb4400c from 'nuxt_plugin_plugin_ddb4400c' // Source: .\\components\\plugin.js (mode: 'all')
import nuxt_plugin_plugin_37ec6e3a from 'nuxt_plugin_plugin_37ec6e3a' // Source: .\\vuetify\\plugin.js (mode: 'all')
import nuxt_plugin_pluginutils_6ec470f1 from 'nuxt_plugin_pluginutils_6ec470f1' // Source: .\\nuxt-i18n\\plugin.utils.js (mode: 'all')
import nuxt_plugin_pluginrouting_f526f408 from 'nuxt_plugin_pluginrouting_f526f408' // Source: .\\nuxt-i18n\\plugin.routing.js (mode: 'all')
import nuxt_plugin_pluginmain_232e86f3 from 'nuxt_plugin_pluginmain_232e86f3' // Source: .\\nuxt-i18n\\plugin.main.js (mode: 'all')
import nuxt_plugin_nuxtgooglemaps_490dd59a from 'nuxt_plugin_nuxtgooglemaps_490dd59a' // Source: .\\nuxt-google-maps.js (mode: 'all')
import nuxt_plugin_pluginclient_5242b3b0 from 'nuxt_plugin_pluginclient_5242b3b0' // Source: .\\content\\plugin.client.js (mode: 'client')
import nuxt_plugin_pluginserver_9007b590 from 'nuxt_plugin_pluginserver_9007b590' // Source: .\\content\\plugin.server.js (mode: 'server')
import nuxt_plugin_workbox_777fc60e from 'nuxt_plugin_workbox_777fc60e' // Source: .\\workbox.js (mode: 'client')
import nuxt_plugin_metaplugin_7841ef0e from 'nuxt_plugin_metaplugin_7841ef0e' // Source: .\\pwa\\meta.plugin.js (mode: 'all')
import nuxt_plugin_iconplugin_6ef2a426 from 'nuxt_plugin_iconplugin_6ef2a426' // Source: .\\pwa\\icon.plugin.js (mode: 'all')
import nuxt_plugin_axios_09fc09c6 from 'nuxt_plugin_axios_09fc09c6' // Source: .\\axios.js (mode: 'all')
import nuxt_plugin_vuexpersist_13f465a2 from 'nuxt_plugin_vuexpersist_13f465a2' // Source: ..\\plugins\\vuex-persist (mode: 'all')
import nuxt_plugin_nuxtquillplugin_36d64ccf from 'nuxt_plugin_nuxtquillplugin_36d64ccf' // Source: ..\\plugins\\nuxt-quill-plugin (mode: 'client')
import nuxt_plugin_importdesignelements_09e2a0f4 from 'nuxt_plugin_importdesignelements_09e2a0f4' // Source: ..\\plugins\\import-design-elements (mode: 'all')
import nuxt_plugin_globalfn_5a640dbe from 'nuxt_plugin_globalfn_5a640dbe' // Source: ..\\plugins\\globalfn (mode: 'all')
import nuxt_plugin_country_1fe68b60 from 'nuxt_plugin_country_1fe68b60' // Source: ..\\plugins\\country (mode: 'all')
import nuxt_plugin_langadmin_6d8e412a from 'nuxt_plugin_langadmin_6d8e412a' // Source: ..\\plugins\\langadmin (mode: 'all')
import nuxt_plugin_i18n_6a80ea94 from 'nuxt_plugin_i18n_6a80ea94' // Source: ..\\plugins\\i18n (mode: 'all')
import nuxt_plugin_api_5e4622e4 from 'nuxt_plugin_api_5e4622e4' // Source: ..\\plugins\\api (mode: 'all')
import nuxt_plugin_owl_47c2522e from 'nuxt_plugin_owl_47c2522e' // Source: ..\\plugins\\owl.js (mode: 'client')
import nuxt_plugin_photoswipe_2d55ce0e from 'nuxt_plugin_photoswipe_2d55ce0e' // Source: ..\\plugins\\photoswipe.js (mode: 'client')
import nuxt_plugin_apexchart_b114e21e from 'nuxt_plugin_apexchart_b114e21e' // Source: ..\\plugins\\apexchart.js (mode: 'client')
import nuxt_plugin_mapbox_80e2041c from 'nuxt_plugin_mapbox_80e2041c' // Source: ..\\plugins\\mapbox.js (mode: 'client')

// Component: <ClientOnly>
Vue.component(ClientOnly.name, ClientOnly)

// TODO: Remove in Nuxt 3: <NoSsr>
Vue.component(NoSsr.name, {
  ...NoSsr,
  render (h, ctx) {
    if (process.client && !NoSsr._warned) {
      NoSsr._warned = true

      console.warn('<no-ssr> has been deprecated and will be removed in Nuxt 3, please use <client-only> instead')
    }
    return NoSsr.render(h, ctx)
  }
})

// Component: <NuxtChild>
Vue.component(NuxtChild.name, NuxtChild)
Vue.component('NChild', NuxtChild)

// Component NuxtLink is imported in server.js or client.js

// Component: <Nuxt>
Vue.component(Nuxt.name, Nuxt)

Object.defineProperty(Vue.prototype, '$nuxt', {
  get() {
    return this.$root.$options.$nuxt
  },
  configurable: true
})

Vue.use(Meta, {"keyName":"head","attribute":"data-n-head","ssrAttribute":"data-n-head-ssr","tagIDKeyName":"hid"})

const defaultTransition = {"name":"page","mode":"out-in","appear":false,"appearClass":"appear","appearActiveClass":"appear-active","appearToClass":"appear-to"}

const originalRegisterModule = Vuex.Store.prototype.registerModule

function registerModule (path, rawModule, options = {}) {
  const preserveState = process.client && (
    Array.isArray(path)
      ? !!path.reduce((namespacedState, path) => namespacedState && namespacedState[path], this.state)
      : path in this.state
  )
  return originalRegisterModule.call(this, path, rawModule, { preserveState, ...options })
}

async function createApp(ssrContext, config = {}) {
  const router = await createRouter(ssrContext, config)

  const store = createStore(ssrContext)
  // Add this.$router into store actions/mutations
  store.$router = router

  // Fix SSR caveat https://github.com/nuxt/nuxt.js/issues/3757#issuecomment-414689141
  store.registerModule = registerModule

  // Create Root instance

  // here we inject the router and store to all child components,
  // making them available everywhere as `this.$router` and `this.$store`.
  const app = {
    head: {"titleTemplate":"%s - CamperGold","title":"CamperGold","meta":[{"charset":"utf-8"},{"name":"viewport","content":"width=device-width, initial-scale=1"},{"hid":"description","name":"description","content":"CamperGold"},{"name":"facebook-domain-verification","content":"k8lfms1dq94sq5znb2ydag3rv1421j"}],"link":[{"rel":"icon","type":"image\u002Fx-icon","href":"\u002Ficon.png"},{"rel":"stylesheet","type":"text\u002Fcss","href":"https:\u002F\u002Ffonts.googleapis.com\u002Fcss?family=Roboto:100,300,400,500,700,900&display=swap"},{"rel":"stylesheet","type":"text\u002Fcss","href":"https:\u002F\u002Fcdn.jsdelivr.net\u002Fnpm\u002F@mdi\u002Ffont@latest\u002Fcss\u002Fmaterialdesignicons.min.css"}],"style":[],"script":[]},

    store,
    router,
    nuxt: {
      defaultTransition,
      transitions: [defaultTransition],
      setTransitions (transitions) {
        if (!Array.isArray(transitions)) {
          transitions = [transitions]
        }
        transitions = transitions.map((transition) => {
          if (!transition) {
            transition = defaultTransition
          } else if (typeof transition === 'string') {
            transition = Object.assign({}, defaultTransition, { name: transition })
          } else {
            transition = Object.assign({}, defaultTransition, transition)
          }
          return transition
        })
        this.$options.nuxt.transitions = transitions
        return transitions
      },

      err: null,
      dateErr: null,
      error (err) {
        err = err || null
        app.context._errored = Boolean(err)
        err = err ? normalizeError(err) : null
        let nuxt = app.nuxt // to work with @vue/composition-api, see https://github.com/nuxt/nuxt.js/issues/6517#issuecomment-573280207
        if (this) {
          nuxt = this.nuxt || this.$options.nuxt
        }
        nuxt.dateErr = Date.now()
        nuxt.err = err
        // Used in src/server.js
        if (ssrContext) {
          ssrContext.nuxt.error = err
        }
        return err
      }
    },
    ...App
  }

  // Make app available into store via this.app
  store.app = app

  const next = ssrContext ? ssrContext.next : location => app.router.push(location)
  // Resolve route
  let route
  if (ssrContext) {
    route = router.resolve(ssrContext.url).route
  } else {
    const path = getLocation(router.options.base, router.options.mode)
    route = router.resolve(path).route
  }

  // Set context to app.context
  await setContext(app, {
    store,
    route,
    next,
    error: app.nuxt.error.bind(app),
    payload: ssrContext ? ssrContext.payload : undefined,
    req: ssrContext ? ssrContext.req : undefined,
    res: ssrContext ? ssrContext.res : undefined,
    beforeRenderFns: ssrContext ? ssrContext.beforeRenderFns : undefined,
    ssrContext
  })

  function inject(key, value) {
    if (!key) {
      throw new Error('inject(key, value) has no key provided')
    }
    if (value === undefined) {
      throw new Error(`inject('${key}', value) has no value provided`)
    }

    key = '$' + key
    // Add into app
    app[key] = value
    // Add into context
    if (!app.context[key]) {
      app.context[key] = value
    }

    // Add into store
    store[key] = app[key]

    // Check if plugin not already installed
    const installKey = '__nuxt_' + key + '_installed__'
    if (Vue[installKey]) {
      return
    }
    Vue[installKey] = true
    // Call Vue.use() to install the plugin into vm
    Vue.use(() => {
      if (!Object.prototype.hasOwnProperty.call(Vue.prototype, key)) {
        Object.defineProperty(Vue.prototype, key, {
          get () {
            return this.$root.$options[key]
          }
        })
      }
    })
  }

  // Inject runtime config as $config
  inject('config', config)

  if (process.client) {
    // Replace store state before plugins execution
    if (window.__NUXT__ && window.__NUXT__.state) {
      store.replaceState(window.__NUXT__.state)
    }
  }

  // Add enablePreview(previewData = {}) in context for plugins
  if (process.static && process.client) {
    app.context.enablePreview = function (previewData = {}) {
      app.previewData = Object.assign({}, previewData)
      inject('preview', previewData)
    }
  }
  // Plugin execution

  if (typeof nuxt_plugin_plugin_ddb4400c === 'function') {
    await nuxt_plugin_plugin_ddb4400c(app.context, inject)
  }

  if (typeof nuxt_plugin_plugin_37ec6e3a === 'function') {
    await nuxt_plugin_plugin_37ec6e3a(app.context, inject)
  }

  if (typeof nuxt_plugin_pluginutils_6ec470f1 === 'function') {
    await nuxt_plugin_pluginutils_6ec470f1(app.context, inject)
  }

  if (typeof nuxt_plugin_pluginrouting_f526f408 === 'function') {
    await nuxt_plugin_pluginrouting_f526f408(app.context, inject)
  }

  if (typeof nuxt_plugin_pluginmain_232e86f3 === 'function') {
    await nuxt_plugin_pluginmain_232e86f3(app.context, inject)
  }

  if (typeof nuxt_plugin_nuxtgooglemaps_490dd59a === 'function') {
    await nuxt_plugin_nuxtgooglemaps_490dd59a(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_pluginclient_5242b3b0 === 'function') {
    await nuxt_plugin_pluginclient_5242b3b0(app.context, inject)
  }

  if (process.server && typeof nuxt_plugin_pluginserver_9007b590 === 'function') {
    await nuxt_plugin_pluginserver_9007b590(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_workbox_777fc60e === 'function') {
    await nuxt_plugin_workbox_777fc60e(app.context, inject)
  }

  if (typeof nuxt_plugin_metaplugin_7841ef0e === 'function') {
    await nuxt_plugin_metaplugin_7841ef0e(app.context, inject)
  }

  if (typeof nuxt_plugin_iconplugin_6ef2a426 === 'function') {
    await nuxt_plugin_iconplugin_6ef2a426(app.context, inject)
  }

  if (typeof nuxt_plugin_axios_09fc09c6 === 'function') {
    await nuxt_plugin_axios_09fc09c6(app.context, inject)
  }

  if (typeof nuxt_plugin_vuexpersist_13f465a2 === 'function') {
    await nuxt_plugin_vuexpersist_13f465a2(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_nuxtquillplugin_36d64ccf === 'function') {
    await nuxt_plugin_nuxtquillplugin_36d64ccf(app.context, inject)
  }

  if (typeof nuxt_plugin_importdesignelements_09e2a0f4 === 'function') {
    await nuxt_plugin_importdesignelements_09e2a0f4(app.context, inject)
  }

  if (typeof nuxt_plugin_globalfn_5a640dbe === 'function') {
    await nuxt_plugin_globalfn_5a640dbe(app.context, inject)
  }

  if (typeof nuxt_plugin_country_1fe68b60 === 'function') {
    await nuxt_plugin_country_1fe68b60(app.context, inject)
  }

  if (typeof nuxt_plugin_langadmin_6d8e412a === 'function') {
    await nuxt_plugin_langadmin_6d8e412a(app.context, inject)
  }

  if (typeof nuxt_plugin_i18n_6a80ea94 === 'function') {
    await nuxt_plugin_i18n_6a80ea94(app.context, inject)
  }

  if (typeof nuxt_plugin_api_5e4622e4 === 'function') {
    await nuxt_plugin_api_5e4622e4(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_owl_47c2522e === 'function') {
    await nuxt_plugin_owl_47c2522e(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_photoswipe_2d55ce0e === 'function') {
    await nuxt_plugin_photoswipe_2d55ce0e(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_apexchart_b114e21e === 'function') {
    await nuxt_plugin_apexchart_b114e21e(app.context, inject)
  }

  if (process.client && typeof nuxt_plugin_mapbox_80e2041c === 'function') {
    await nuxt_plugin_mapbox_80e2041c(app.context, inject)
  }

  // Lock enablePreview in context
  if (process.static && process.client) {
    app.context.enablePreview = function () {
      console.warn('You cannot call enablePreview() outside a plugin.')
    }
  }

  // If server-side, wait for async component to be resolved first
  if (process.server && ssrContext && ssrContext.url) {
    await new Promise((resolve, reject) => {
      router.push(ssrContext.url, resolve, (err) => {
        // https://github.com/vuejs/vue-router/blob/v3.4.3/src/util/errors.js
        if (!err._isRouter) return reject(err)
        if (err.type !== 2 /* NavigationFailureType.redirected */) return resolve()

        // navigated to a different route in router guard
        const unregister = router.afterEach(async (to, from) => {
          ssrContext.url = to.fullPath
          app.context.route = await getRouteData(to)
          app.context.params = to.params || {}
          app.context.query = to.query || {}
          unregister()
          resolve()
        })
      })
    })
  }

  return {
    store,
    app,
    router
  }
}

export { createApp, NuxtError }
