<template>
  <v-row class="mx-1 mt-2 mb-4">
    <slot />
  </v-row>
</template>
