<template>
  <AdminAddonPageAdd
    :type="'addon'"
    :name="$langAdmin('Addon')"
    :base-url="'/admin/addons/'"
  />
</template>

<script>
import AdminAddonPageAdd from '~/components/admin/pages/AdminAddonPageAdd'
export default {
  layout: 'admin',
  components: {
    AdminAddonPageAdd
  },
  head () {
    return {
      title: this.$langAdmin('AddAddonTitle'),
      meta: [
        {
          hid: 'description',
          name: 'description',
          content: this.$langAdmin('AddAddonDes')
        }
      ]
    }
  }
}
</script>
