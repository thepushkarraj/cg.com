import Vue from 'vue'
import OwlCarousel from 'v-owl-carousel'
Vue.component('carousel', OwlCarousel)
