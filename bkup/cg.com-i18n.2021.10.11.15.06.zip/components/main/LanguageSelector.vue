<template>
  <span>
    <v-menu offset-y>
      <template v-slot:activator="{ on, attrs }">
        <v-btn class="transparent" depressed v-bind="attrs" v-on="on">
          <v-avatar size="30" class="teal mr-0">
            <v-img :src="$getLangFlag" />
          </v-avatar>
          <span class="ml-2 d-none d-sm-flex"> {{ $getLangCode }} </span>
        </v-btn>
        <nuxt-link
          class="white--text"
          :to="switchLocalePath('de')"
        >
          de
        </nuxt-link>
        <nuxt-link
          class="white--text"
          :to="switchLocalePath('en')"
        >
          en
        </nuxt-link>
      </template>
      <v-list style="min-width: 200px;">
        <v-list-item
          v-for="item,index in $allStateLanguages"
          :key="index"
          v-show="item.code !== 'nl'"
          @click="setUserLang(item.show)"
        >
          <!-- @click="setUserLang(item.show)" -->
          <v-avatar size="30" class="teal mr-2">
            <v-img :src="item.flag" />
          </v-avatar>
          {{ item.name }}
        </v-list-item>
      </v-list>
    </v-menu>
  </span>
</template>

<script>
export default {
  mounted () {
    if (this.$userRole()) {
      this.$api(this.$userRole() + '/update-language/' + this.$getLang + '/' + this.$getLangCode)
    }
  },
  methods: {
    setUserLang (lang) {
      // this.$onLanguageSwitched('en', 'de')
      this.$store.commit('setLang', lang)
      window.location.reload()
    }
  }
}
</script>
