export default function (context) {
  // const login = context.store.getters.isLogin
  // console.log(login)
  // console.log(login)
  // console.log(context.route.path)
}
