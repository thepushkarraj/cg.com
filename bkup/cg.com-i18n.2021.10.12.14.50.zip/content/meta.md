---
home: {
  title: {
    en: 'Hire A Camper With Camper Gold',
    de: 'Hire A Camper With Camper Gold',
    nl: 'Hire A Camper With Camper Gold',
    zh: 'Hire A Camper With Camper Gold'
  },
  description: {
    en: 'Hire A Camper With Camper Gold',
    de: 'Hire A Camper With Camper Gold',
    nl: 'Hire A Camper With Camper Gold',
    zh: 'Hire A Camper With Camper Gold'
  },
}
impressum: {
  title: {
    en: 'impressum',
    de: 'impressum de',
    nl: 'impressum nl',
    zh: 'impressum zh'
  },
  description: {
    en: 'impressum description',
    de: 'impressum description de',
    nl: 'impressum description nl',
    zh: 'impressum description zh'
  },
}
about: {
  title: {
    en: 'about',
    de: 'about de',
    nl: 'about nl',
    zh: 'about zh'
  },
  description: {
    en: 'about description',
    de: 'about description de',
    nl: 'about description nl',
    zh: 'about description zh'
  },
}
contact: {
  title: {
    en: 'contact',
    de: 'contact de',
    nl: 'contact nl',
    zh: 'contact zh'
  },
  description: {
    en: 'contact description',
    de: 'contact description de',
    nl: 'contact description nl',
    zh: 'contact description zh'
  },
}
adminpost: {
  title: {
    en: 'blog',
    de: 'home de',
    nl: 'home nl',
    zh: 'home zh'
  },
  description: {
    en: 'home description',
    de: 'home description de',
    nl: 'home description nl',
    zh: 'home description zh'
  },
}
adminpostadd: {
  title: {
    en: 'Add Post',
    de: 'Add Post de',
    nl: 'Add Post nl',
    zh: 'Add Post zh'
  },
  description: {
    en: 'Add Post description',
    de: 'Add Post description de',
    nl: 'Add Post description nl',
    zh: 'Add Post description zh'
  },
}
adminpostedit: {
  title: {
    en: 'Edit Post',
    de: 'Edit Post de',
    nl: 'Edit Post nl',
    zh: 'Edit Post zh'
  },
  description: {
    en: 'Edit Post description',
    de: 'Edit Post description de',
    nl: 'Edit Post description nl',
    zh: 'Edit Post description zh'
  },
}
adminpostcat: {
  title: {
    en: 'Post Category',
    de: 'Post Category de',
    nl: 'Post Category nl',
    zh: 'Post Category zh'
  },
  description: {
    en: 'Post Category description',
    de: 'Post Category description de',
    nl: 'Post Category description nl',
    zh: 'Post Category description zh'
  },
}
adminpostcatadd: {
  title: {
    en: 'Add Post Category',
    de: 'Add Post Category de',
    nl: 'Add Post Category nl',
    zh: 'Add Post Category zh'
  },
  description: {
    en: 'Add Post Category description',
    de: 'Add Post Category description de',
    nl: 'Add Post Category description nl',
    zh: 'Add Post Category description zh'
  },
}
adminpostcatedit: {
  title: {
    en: 'Edit Post Category',
    de: 'Edit Post Category de',
    nl: 'Edit Post Category nl',
    zh: 'Edit Post Category zh'
  },
  description: {
    en: 'Edit Post Category description',
    de: 'Edit Post Category description de',
    nl: 'Edit Post Category description nl',
    zh: 'Edit Post Category description zh'
  },
}
admincoupon: {
  title: {
    en: 'Coupon',
    de: 'Coupon de',
    nl: 'Coupon nl',
    zh: 'Coupon zh'
  },
  description: {
    en: 'Coupon description',
    de: 'Coupon description de',
    nl: 'Coupon description nl',
    zh: 'Coupon description zh'
  },
}
admincouponadd: {
  title: {
    en: 'Add Coupon',
    de: 'Add Coupon de',
    nl: 'Add Coupon nl',
    zh: 'Add Coupon zh'
  },
  description: {
    en: 'Add Coupon description',
    de: 'Add Coupon description de',
    nl: 'Add Coupon description nl',
    zh: 'Add Coupon description zh'
  },
}
admincouponedit: {
  title: {
    en: 'Edit Coupon',
    de: 'Edit Coupon de',
    nl: 'Edit Coupon nl',
    zh: 'Edit Coupon zh'
  },
  description: {
    en: 'Edit Coupon description',
    de: 'Edit Coupon description de',
    nl: 'Edit Coupon description nl',
    zh: 'Edit Coupon description zh'
  },
}
admincamper: {
  title: {
    en: 'Camper',
    de: 'Camper de',
    nl: 'Camper nl',
    zh: 'Camper zh'
  },
  description: {
    en: 'Camper description',
    de: 'Camper description de',
    nl: 'Camper description nl',
    zh: 'Camper description zh'
  },
}
admincamperadd: {
  title: {
    en: 'Add Camper',
    de: 'Add Camper de',
    nl: 'Add Camper nl',
    zh: 'Add Camper zh'
  },
  description: {
    en: 'Add Camper description',
    de: 'Add Camper description de',
    nl: 'Add Camper description nl',
    zh: 'Add Camper description zh'
  },
}
admincamperedit: {
  title: {
    en: 'Edit Camper',
    de: 'Edit Camper de',
    nl: 'Edit Camper nl',
    zh: 'Edit Camper zh'
  },
  description: {
    en: 'Edit Camper description',
    de: 'Edit Camper description de',
    nl: 'Edit Camper description nl',
    zh: 'Edit Camper description zh'
  },
}
adminpage: {
  title: {
    en: 'Page',
    de: 'Page de',
    nl: 'Page nl',
    zh: 'Page zh'
  },
  description: {
    en: 'Page description',
    de: 'Page description de',
    nl: 'Page description nl',
    zh: 'Page description zh'
  },
}
adminpageadd: {
  title: {
    en: 'Add Page',
    de: 'Add Page de',
    nl: 'Add Page nl',
    zh: 'Add Page zh'
  },
  description: {
    en: 'Add Page description',
    de: 'Add Page description de',
    nl: 'Add Page description nl',
    zh: 'Add Page description zh'
  },
}
adminpageedit: {
  title: {
    en: 'Edit Page',
    de: 'Edit Page de',
    nl: 'Edit Page nl',
    zh: 'Edit Page zh'
  },
  description: {
    en: 'Edit Page description',
    de: 'Edit Page description de',
    nl: 'Edit Page description nl',
    zh: 'Edit Page description zh'
  },
}
adminfaq: {
  title: {
    en: 'Faq',
    de: 'Faq de',
    nl: 'Faq nl',
    zh: 'Faq zh'
  },
  description: {
    en: 'Faq description',
    de: 'Faq description de',
    nl: 'Faq description nl',
    zh: 'Faq description zh'
  },
}
adminfaqadd: {
  title: {
    en: 'Add Faq',
    de: 'Add Faq de',
    nl: 'Add Faq nl',
    zh: 'Add Faq zh'
  },
  description: {
    en: 'Add Faq description',
    de: 'Add Faq description de',
    nl: 'Add Faq description nl',
    zh: 'Add Faq description zh'
  },
}
adminfaqedit: {
  title: {
    en: 'Edit Faq',
    de: 'Edit Faq de',
    nl: 'Edit Faq nl',
    zh: 'Edit Faq zh'
  },
  description: {
    en: 'Edit Faq description',
    de: 'Edit Faq description de',
    nl: 'Edit Faq description nl',
    zh: 'Edit Faq description zh'
  },
}
adminfaqcat: {
  title: {
    en: 'Faq Category',
    de: 'Faq Category de',
    nl: 'Faq Category nl',
    zh: 'Faq Category zh'
  },
  description: {
    en: 'Faq Category description',
    de: 'Faq Category description de',
    nl: 'Faq Category description nl',
    zh: 'Faq Category description zh'
  },
}
adminfaqcatadd: {
  title: {
    en: 'Add Faq Category',
    de: 'Add Faq Category de',
    nl: 'Add Faq Category nl',
    zh: 'Add Faq Category zh'
  },
  description: {
    en: 'Add Faq Category description',
    de: 'Add Faq Category description de',
    nl: 'Add Faq Category description nl',
    zh: 'Add Faq Category description zh'
  },
}
adminfaqcatedit: {
  title: {
    en: 'Edit Faq Category',
    de: 'Edit Faq Category de',
    nl: 'Edit Faq Category nl',
    zh: 'Edit Faq Category zh'
  },
  description: {
    en: 'Edit Faq Category description',
    de: 'Edit Faq Category description de',
    nl: 'Edit Faq Category description nl',
    zh: 'Edit Faq Category description zh'
  },
}
admincampercat: {
  title: {
    en: 'Camper Category',
    de: 'Camper Category de',
    nl: 'Camper Category nl',
    zh: 'Camper Category zh'
  },
  description: {
    en: 'Camper Category description',
    de: 'Camper Category description de',
    nl: 'Camper Category description nl',
    zh: 'Camper Category description zh'
  },
}
admincampercatadd: {
  title: {
    en: 'Add Camper Category',
    de: 'Add Camper Category de',
    nl: 'Add Camper Category nl',
    zh: 'Add Camper Category zh'
  },
  description: {
    en: 'Add Camper Category description',
    de: 'Add Camper Category description de',
    nl: 'Add Camper Category description nl',
    zh: 'Add Camper Category description zh'
  },
}
admincampercatedit: {
  title: {
    en: 'Edit Camper Category',
    de: 'Edit Camper Category de',
    nl: 'Edit Camper Category nl',
    zh: 'Edit Camper Category zh'
  },
  description: {
    en: 'Edit Camper Category description',
    de: 'Edit Camper Category description de',
    nl: 'Edit Camper Category description nl',
    zh: 'Edit Camper Category description zh'
  },
}
adminuserlist: {
  title: {
    en: 'User List',
    de: 'User List de',
    nl: 'User List nl',
    zh: 'User List zh'
  },
  description: {
    en: 'User List description',
    de: 'User List description de',
    nl: 'User List description nl',
    zh: 'User List description zh'
  },
}
---