<template>
  <v-row>
    <div class="col-md-3">
      <h3 class="pt-sm-16 pt-0">
        {{ $multiLang('PricePerDay') }}
      </h3>
    </div>
    <div class="col-md-3">
      <p>
        <v-icon color="primary" class="mr-2">
          mdi-clipboard-check
        </v-icon>
        {{ $multiLang('StandardSeason') }} <br>
        <v-icon color="primary" class="mr-2">
          mdi-calendar
        </v-icon>
        {{ $multiLang('AprJunSepOct') }}
      </p>
      <TextInput
        class="mt-3"
        :label="$langAdmin('StandardSeasonPrice')"
        :name="'first_season'"
        :required="false"
        prepend-inner-icon="mdi-map-marker"
      />
    </div>
    <div class="col-md-3">
      <p>
        <v-icon color="primary" class="mr-2">
          mdi-clipboard-check
        </v-icon>
        {{ $multiLang('HighSeason') }} <br>
        <v-icon color="primary" class="mr-2">
          mdi-calendar
        </v-icon>
        {{ $multiLang('JulAug') }}
      </p>
      <TextInput
        class="mt-3"
        :label="$langAdmin('HighSeasonPrice')"
        :name="'second_season'"
        :required="false"
      />
    </div>
    <div class="col-md-3">
      <p>
        <v-icon color="primary" class="mr-2">
          mdi-clipboard-check
        </v-icon>
        {{ $multiLang('WinterSeason') }} <br>
        <v-icon color="primary" class="mr-2">
          mdi-calendar
        </v-icon>
        {{ $multiLang('NovMar') }}
      </p>
      <TextInput
        class="mt-3"
        :label="$langAdmin('WinterSeasonPrice')"
        :name="'third_season'"
        :required="false"
      />
    </div>
  </v-row>
</template>
