<template>
  <span />
</template>

<script>
export default {
  layout: 'web'
}
</script>
