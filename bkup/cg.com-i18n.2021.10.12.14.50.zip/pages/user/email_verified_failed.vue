<template>
  <div class="container-fluid grey lighten-4">
    <v-container>
      <v-row>
        <div class="col-md-8 offset-md-2">
          <v-card class="mx-2 my-12">
            <v-row>
              <div class="col-md-12">
                <img src="/img/email_verified_failed.jpg" style="width:100%; max-width:400px;">
              </div>
              <div class="col-md-12 text-center">
                <h2>{{ $multiLang('EmailVerifiedFail') }}</h2>
              </div>
            </v-row>
          </v-card>
        </div>
      </v-row>
    </v-container>
  </div>
</template>
