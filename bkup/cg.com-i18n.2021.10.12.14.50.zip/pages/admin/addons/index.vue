<template>
  <AdminPageList :type="'addon'" :name="$langAdmin('Addon')" :base-url="'/admin/addons/'" />
</template>

<script>
import AdminPageList from '~/components/admin/pages/AdminPageList'
export default {
  layout: 'admin',
  components: {
    AdminPageList
  },
  head () {
    return {
      title: this.$langAdmin('AddonTitle'),
      meta: [
        {
          hid: 'description',
          name: 'description',
          content: this.$langAdmin('AddonDes')
        }
      ]
    }
  }
}

</script>
