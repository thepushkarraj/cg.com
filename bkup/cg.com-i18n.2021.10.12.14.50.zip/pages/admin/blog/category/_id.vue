<template>
  <AdminCategoryEdit
    :type="'blog'"
    :name="$langAdmin('BlogCategory')"
    :base-url="'/admin/blog/category/'"
  />
</template>

<script>
import AdminCategoryEdit from '~/components/admin/category/AdminCategoryEdit'
export default {
  layout: 'admin',
  components: {
    AdminCategoryEdit
  },
  head () {
    return {
      title: this.$langAdmin('EditCategoryTitle'),
      meta: [
        {
          hid: 'description',
          name: 'description',
          content: this.$langAdmin('EditCategoryDes')
        }
      ]
    }
  }
}
</script>
