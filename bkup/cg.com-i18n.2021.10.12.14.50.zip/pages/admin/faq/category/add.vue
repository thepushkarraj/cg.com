<template>
  <AdminCategoryAdd
    :type="'faq'"
    :name="$langAdmin('FaqCategory')"
    :base-url="'/admin/faq/category/'"
  />
</template>

<script>
import AdminCategoryAdd from '~/components/admin/category/AdminCategoryAdd'
export default {
  layout: 'admin',
  components: {
    AdminCategoryAdd
  },
  head () {
    return {
      title: this.$langAdmin('AddCategoryTitle'),
      meta: [
        {
          hid: 'description',
          name: 'description',
          content: this.$langAdmin('AddCategoryDes')
        }
      ]
    }
  }
}
</script>
