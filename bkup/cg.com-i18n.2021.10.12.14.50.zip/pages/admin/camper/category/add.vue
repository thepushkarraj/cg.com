<template>
  <AdminCategoryAdd
    :type="'camper'"
    :name="$langAdmin('CamperType')"
    :base-url="'/admin/camper/category/'"
  />
</template>

<script>
import AdminCategoryAdd from '~/components/admin/category/AdminCategoryAdd'
export default {
  layout: 'admin',
  components: {
    AdminCategoryAdd
  },
  head () {
    return {
      title: this.$langAdmin('AddCamperTypeTitle'),
      meta: [
        {
          hid: 'description',
          name: 'description',
          content: this.$langAdmin('AddCamperTypeDes')
        }
      ]
    }
  }
}
</script>
