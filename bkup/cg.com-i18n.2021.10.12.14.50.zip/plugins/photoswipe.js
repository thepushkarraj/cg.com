import Vue from 'vue'
import VuePictureSwipe from 'vue-picture-swipe'
Vue.component('VuePictureSwipe', VuePictureSwipe)
