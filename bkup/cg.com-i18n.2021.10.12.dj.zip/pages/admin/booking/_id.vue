<template>
  <SingleBookingView />
</template>

<script>
export default {
  layout: 'admin'
}
</script>
