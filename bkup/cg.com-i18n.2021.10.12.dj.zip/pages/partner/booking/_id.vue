<template>
  <SingleBookingView />
</template>

<script>
export default {
  layout: 'partner'
}
</script>
