<template>
  <span />
</template>

<script>
export default {
  mounted () {
    this.$store.commit('setUserLogout')
    window.location.href = '/'
  }
}
</script>
