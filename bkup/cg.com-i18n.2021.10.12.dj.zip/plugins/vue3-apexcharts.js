import Vue from 'vue'
import VueApexCharts from 'vue3-apexcharts'
Vue.component('VueApexCharts', VueApexCharts)
