import locale7073d68e from '../..\\lang\\de_DE.js'

export const Constants = {
  COMPONENT_OPTIONS_KEY: "nuxtI18n",
  STRATEGIES: {"PREFIX":"prefix","PREFIX_EXCEPT_DEFAULT":"prefix_except_default","PREFIX_AND_DEFAULT":"prefix_and_default","NO_PREFIX":"no_prefix"},
  REDIRECT_ON_OPTIONS: {"ALL":"all","ROOT":"root","NO_PREFIX":"no prefix"},
}
export const nuxtOptions = {
  isUniversalMode: true,
  trailingSlash: undefined,
}
export const options = {
  vueI18n: {"fallbackLocale":"de"},
  vueI18nLoader: false,
  locales: [{"code":"de","file":"de_DE.js"},{"code":"us","file":"en_US.js"},{"code":"uk","file":"en_UK.js"},{"code":"ca","file":"en_CA.js"},{"code":"tw","file":"zh_TW.js"},{"code":"cn","file":"zh_ZH.js"},{"code":"nl","file":"nl_NL.js"}],
  defaultLocale: "de",
  defaultDirection: "ltr",
  routesNameSeparator: "___",
  defaultLocaleRouteNameSuffix: "default",
  sortRoutes: true,
  strategy: "prefix_except_default",
  lazy: true,
  langDir: "C:\\Users\\stegpearl.com\\Desktop\\cg.com-i18n\\lang",
  rootRedirect: null,
  detectBrowserLanguage: {"alwaysRedirect":false,"cookieCrossOrigin":false,"cookieDomain":null,"cookieKey":"i18n_redirected","cookieSecure":false,"fallbackLocale":"","redirectOn":"root","useCookie":true},
  differentDomains: false,
  baseUrl: "",
  vuex: {"moduleName":"i18n","syncRouteParams":true},
  parsePages: true,
  pages: {},
  skipSettingLocaleOnNavigate: false,
  onBeforeLanguageSwitch: () => {},
  onLanguageSwitched: () => null,
  normalizedLocales: [{"code":"de","file":"de_DE.js"},{"code":"us","file":"en_US.js"},{"code":"uk","file":"en_UK.js"},{"code":"ca","file":"en_CA.js"},{"code":"tw","file":"zh_TW.js"},{"code":"cn","file":"zh_ZH.js"},{"code":"nl","file":"nl_NL.js"}],
  localeCodes: ["de","us","uk","ca","tw","cn","nl"],
}

export const localeMessages = {
  'de_DE.js': () => Promise.resolve(locale7073d68e),
  'en_US.js': () => import('../..\\lang\\en_US.js' /* webpackChunkName: "lang-en_US.js" */),
  'en_UK.js': () => import('../..\\lang\\en_UK.js' /* webpackChunkName: "lang-en_UK.js" */),
  'en_CA.js': () => import('../..\\lang\\en_CA.js' /* webpackChunkName: "lang-en_CA.js" */),
  'zh_TW.js': () => import('../..\\lang\\zh_TW.js' /* webpackChunkName: "lang-zh_TW.js" */),
  'zh_ZH.js': () => import('../..\\lang\\zh_ZH.js' /* webpackChunkName: "lang-zh_ZH.js" */),
  'nl_NL.js': () => import('../..\\lang\\nl_NL.js' /* webpackChunkName: "lang-nl_NL.js" */),
}
